
function spline_test_d()

% Function to interpolate

% Data at equispaced points

xdata = A(:,2);
ydata = A(:,3);

% Build the spline.  Currently, the derivatives at nodes are all set to
% zero.  Your job is to come up with a nicer spline by modifying
% the routines below.
math465 = false;
if (math465)
    pp = math465_build_spline(xdata,ydata);    
else
    end_cond = 'natural';                         % 'natural' or 'clamped'
    end_data = [ydata(1); ydata(2)]';   % For 'clamped' endpoint condition

    pp = math565_build_spline(xdata,ydata,end_cond,end_data);
end

% Evaluate the spline at points used for plotting
xv = linspace(0,1,200);
yv = ppval(pp,xv);       % Matlab function

% Plot results
figure(2)
clf;

% Plotting
plot(xv,yv,'r','linewidth',2);
hold on;
plot(xdata,ydata,'k.','markersize',30);
plot(xv,f(xv),'k');
legend('Spline solution','Data','Exact solution','fontsize',16);

xlabel('x','fontsize',16);
ylabel('y','fontsize',16);
title('Spline interpolation','fontsize',18);

shg

end